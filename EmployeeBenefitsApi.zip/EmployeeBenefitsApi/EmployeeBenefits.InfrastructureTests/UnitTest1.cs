using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EmployeeBenefits.InfrastructureTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
